import React, { useState, useEffect } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { useHistory } from "react-router-dom";
import axios from "axios";

export default function Login() {
  const [username, setusername] = useState("");
  const [pw, setpw] = useState("");
  const history = useHistory();
  const [errormsg, seterror] = useState("");

  function HandleSubmit(event) {
    event.preventDefault();

    axios
      .post("http://localhost:3001/login", { username: username, pw: pw })
      .then((res) => {
        console.log(res.data.ver);
        if (res.data.ver === "true") {
          history.push("/movie");
        } else if (res.data.ver === "false") {
          console.log("not in");
          seterror("User not yet registered or password is incorrect");
        }
      }, []);
  }

  return (
    <div>
      <h1>Movie Rating App: Login to rate!</h1>
      <Form onSubmit={HandleSubmit}>
        <Form.Group>
          <Form.Label>Username</Form.Label>
          <Form.Control
            type="text"
            value={username}
            onChange={(e) => setusername(e.target.value)}
          ></Form.Control>
        </Form.Group>
        <Form.Group>
          <Form.Label>Password</Form.Label>
          <Form.Control
            type="password"
            value={pw}
            onChange={(e) => setpw(e.target.value)}
          ></Form.Control>
        </Form.Group>
        <Button type="submit">Login</Button>
      </Form>
      {errormsg && (
        <div className="error" style={{ color: "red" }}>
          {errormsg}
        </div>
      )}
      <h3>
        Wanna rate?<a href="/signup">Signup!</a>
      </h3>
    </div>
  );
}
