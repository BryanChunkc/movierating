import React, { useEffect, useState } from "react";
import axios from "axios";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import { useHistory } from "react-router-dom";
import "./movie.css";

function Movie() {
  const [movies, displaymovies] = useState([]);
  const [rating, setrating] = useState("No rating by user yet.");
  const [received, setrec] = useState([]);
  const Image_url = "https://image.tmdb.org/t/p/w200/";
  const history = useHistory();

  useEffect(() => {
    axios({
      method: "GET",
      url: "http://localhost:3001/movie",
    }).then((res) => {
      console.log(res.data.data.results);
      displaymovies(res.data.data.results);
    });
  }, []);

  function HandleClick(event) {
    // event.preventDefault();
    //console.log(event);
    axios
      .post("http://localhost:3001/rate", {
        id: event.id,
        title: event.title,
        rating: rating,
      })
      .then((res) => {
        console.log(res.data.loggedin);
        if (res.data.loggedin === "false") {
          history.push("/");
        } else {
          setrec(res.data.rating);
        }
      });
  }

  return (
    <div>
      <h1>Welcome to Movie Rating app! Rate a movie!</h1>
      {movies.length > 0 &&
        movies.map((movie) => (
          <div>
            <img src={Image_url + movie.poster_path} alt={movie.title} />
            <div>
              <h2 style={{ color: "Blue" }}>{movie.title}</h2>
            </div>
            <div>
              <h3>
                User rating:
                <span style={{ fontStyle: "italic" }}> {received}</span>
              </h3>
              <Form>
                <Form.Group>
                  <Form.Label>Rate now!: </Form.Label>
                  <Form.Control
                    type="number"
                    pattern="[0-5]"
                    value={rating}
                    onChange={(e) => setrating(e.target.value)}
                  ></Form.Control>
                </Form.Group>
                <Button onClick={() => HandleClick(movie)}>Rate</Button>
              </Form>
            </div>
            <div>
              <h3>--Overview--</h3>
              <p>{movie.overview}</p>
              <br></br>
              <hr class="solid"></hr>
              <br></br>
              <br></br>
            </div>
          </div>
        ))}
    </div>
  );
}

export default Movie;
