import React, { useEffect, useState } from "react";
import axios from "axios";
import "./movie.css";

function Movie() {
  const [movies, displaymovies] = useState([]);
  const Image_url = "https://image.tmdb.org/t/p/w200/";

  useEffect(() => {
    axios({
      method: "GET",
      url: "http://localhost:3001/",
    }).then((res) => {
      console.log(res.data.data.results);
      displaymovies(res.data.data.results);
    });
  }, []);

  return (
    <div>
      <h1>Welcome to Movie Rating app! Rate a movie!</h1>
      {movies.length > 0 &&
        movies.map((movie) => (
          <div>
            <img src={Image_url + movie.poster_path} alt={movie.title} />
            <div>
              <h3>{movie.title}</h3>
              <span>{movie.vote_average}</span>
            </div>

            <div>
              <h2>Overview:</h2>
              <p>{movie.overview}</p>
              <br></br>
              <hr class="solid"></hr>
              <br></br>
              <br></br>
            </div>
          </div>
        ))}
    </div>
  );
}

export default Movie;
