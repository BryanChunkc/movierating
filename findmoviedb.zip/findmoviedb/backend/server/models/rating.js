const { mongoose } = require("../mongoose");

const rating = mongoose.model(
  "rating",
  new mongoose.Schema({
    moviename: String,
    rating: Number,
    username: String,
  })
);

module.exports = rating;
