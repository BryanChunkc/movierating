const fetch = require("node-fetch");
const express = require("express");
const app = express();
const cors = require("cors");
const session = require("express-session");
const MongoStore = require("connect-mongo");
const bodyParser = require("body-parser");

const rating = require("./models/rating");
const user = require("./models/user");

app.use(cors());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(
  session({
    secret: "log into movie rating system",
    store: MongoStore.create({
      mongoUrl: "mongodb://localhost:27017/MovieRating",
    }),
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60 * 1000 },
  })
);

app.get("/", async (req, res) => {
  const url =
    "https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=113c7f5dffed89574dffaa2a18ff9ce0&page=1";
  const options = {
    method: "GET",
  };
  const response = await fetch(url, options);
  const data = await response.json();
  res.send({ data });
  //console.log(data);
});

app.post("/login", async (req, res) => {
  console.log(req.body.username);
  let reged = await user.findOne({
    username: req.body.username,
    pw: req.body.pw,
  });
  if (reged) {
    req.session.user = req.body.username;
    req.session.loggedin = true;
    console.log("corr");
    res.send({ ver: "true" });
  } else {
    console.log("not corr");
    res.send({ ver: "false" });
  }
});

app.post("/signup", async (req, res) => {
  console.log(req.body.username);
  let reged = await user.findOne({
    username: req.body.username,
  });
  if (reged) {
    console.log("reged");
    res.send({ allow: "false" });
  } else {
    console.log("not reged");
    const result = new user(req.body);
    await result.save();
    res.send({ allow: "true" });
  }
});

app.listen(3001, () => {
  console.log("listening 3001");
});
